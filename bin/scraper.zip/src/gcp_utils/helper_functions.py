from google.cloud import storage

def write_bucket(bucket_name, data):
    '''
    Write data to a bucket in GCS

    Args:
        bucket_name (str): Name of the bucket to write to
        data (str): Data to write to the bucket

    Prints:
        str: Message indicating if the data was written successfully
    '''
    print('Writing data to GCS')
    client = storage.Client()
    bucket = client.bucket(bucket_name)
    blob = bucket.blob('data.txt')
    blob.upload_from_string(data)
    print('Data written to GCS')